//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#include "../global.h"

#include <logger/Log.h>

#include "CodeTable.h"
#include <db/Database.h>
#include <itemstructs/ItemSet.h>

#include "StandardCodeTable.h"

StandardCodeTable::StandardCodeTable(uint32 numCounts) {
	mNumCounts = numCounts;
	mCounts = new uint32[mNumCounts];
	mCodeLengths = new double[mNumCounts];
	for(uint32 i=0; i<mNumCounts; i++) {
		mCounts[i] = 0;
		mCodeLengths[i] = 0.0;
	}
	mCountSum = 0;
}

StandardCodeTable::StandardCodeTable(Database *db) {
	alphabet *alph = db->GetAlphabet();
	mNumCounts = alph->size();
	mCounts = new uint32[mNumCounts];
	mCodeLengths = new double[mNumCounts];

	uint32 idx = 0;
	mCountSum = 0;
	for(alphabet::iterator iter = alph->begin(); iter != alph->end(); iter++, idx++) {
		mCounts[idx] = iter->second;
		mCountSum += mCounts[idx];
	}
	if(idx != mNumCounts)
		throw string("StandardCodeTable -- Number of alphabet elements incorrect?!");

	UpdateCodeLengths();
}

StandardCodeTable::StandardCodeTable(uint32 *counts, uint32 numCounts) {
	mNumCounts = numCounts;
	mCounts = counts;
	mCodeLengths = new double[mNumCounts];

	mCountSum = 0;
	for(uint32 i=0; i<mNumCounts; i++)
		mCountSum += mCounts[i];

	UpdateCodeLengths();
}

StandardCodeTable::~StandardCodeTable() {
	delete[] mCounts;
	delete[] mCodeLengths;
}

void StandardCodeTable::AddLaplace() {
	for(uint32 i=0; i<mNumCounts; i++)
		++mCounts[i];
	mCountSum += mNumCounts;
	++mLaplace;
	UpdateCodeLengths();
}
void StandardCodeTable::RemoveLaplace() {
	if(mLaplace > 0) {
		for(uint32 i=0; i<mNumCounts; i++)
			--mCounts[i];
		mCountSum -= mNumCounts;
		--mLaplace;
		UpdateCodeLengths();
	}
}
double StandardCodeTable::GetCodeLength(uint32 singleton) {
	return mCodeLengths[singleton];
}
double StandardCodeTable::GetCodeLength(ItemSet *is) {
	uint32 *set = is->GetValues();
	double len = GetCodeLength(set, is->GetLength());
	delete[] set;
	return len;
}
double StandardCodeTable::GetCodeLength(uint32 *set, uint32 numItems) {
	double len = 0.0;
	for(uint32 i=0; i<numItems; i++)
		len += mCodeLengths[set[i]];
	return len;
}
void StandardCodeTable::UpdateCodeLengths() {
	for(uint32 i=0; i<mNumCounts; i++)
		mCodeLengths[i] = mCounts[i] == 0 ? 0.0 : CalcCodeLength(mCounts[i], mCountSum);
}
