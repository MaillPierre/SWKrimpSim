//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
// 
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
#include "../blobal.h"

#include <RandomUtils.h>
#include <ArrayUtils.h>

#include "../Bass.h"
#include "../db/Database.h"
#include "../isc/ItemSetCollection.h"

#include "Uint16ItemSet.h"
#include "BAI32ItemSet.h"
#include "BM128ItemSet.h"
#include "ItemSet.h"

#include <algorithm>
#include <cassert>

ItemSet::ItemSet() {
	mID = UINT64_MAX_VALUE;
	mUsageCount = 0;
	mUsageArea = 0;
	mSupport = 0;
	mPrevUsageCount = 0;
	mPrevUsageArea = 0;
	mStdLength = 0.0;
	mDBOccurrence = NULL;
	mNumDBOccurs = 0;
	mUsage = NULL;
	mNumUsages = 0;
	mPrevUsage = NULL;
	mNumPrevUsages = 0;
	mRefCount = 1;


	mCompFunc = &ItemSet::CmpSupport;
}

ItemSet::ItemSet(const ItemSet& is) {
	mID = is.mID;
	mUsageCount = is.mUsageCount;
	mUsageArea = is.mUsageArea;
	mSupport = is.mSupport;
	mPrevUsageCount = is.mPrevUsageCount;
	mPrevUsageArea = is.mPrevUsageArea;
	mStdLength = is.mStdLength;

	mNumDBOccurs = is.mNumDBOccurs;
	mNumUsages = is.mNumUsages;
	mNumPrevUsages = is.mNumPrevUsages;
	if(is.mDBOccurrence == NULL) {
		mDBOccurrence = NULL;
	} else {
		mDBOccurrence = new uint32[mNumDBOccurs];
		memcpy(mDBOccurrence, is.mDBOccurrence, mNumDBOccurs * sizeof(uint32));
	}
	if(is.mUsage == NULL) {
		mUsage = NULL;
	} else {
		mUsage = new uint32[mNumDBOccurs];
		memcpy(mUsage, is.mUsage, mNumUsages * sizeof(uint32));
	}
	if(is.mPrevUsage == NULL) {
		mPrevUsage = NULL;
	} else {
		mPrevUsage = new uint32[mNumDBOccurs];
		memcpy(mPrevUsage, is.mPrevUsage, mNumPrevUsages * sizeof(uint32));
	}
	mRefCount = 1;
}

ItemSet::~ItemSet() {
	if(mRefCount > 1) {
		throw string("Deleting itemset with multiple references");
	}
	delete[] mDBOccurrence;
	delete[] mUsage;
	delete[] mPrevUsage;
}

// set wordt netjes gekopieerd, ownership wordt dus niet overgenomen.
ItemSet *ItemSet::Create(ItemSetType type, const uint32 *set, uint32 setlen, uint32 abetlen, uint32 cnt, uint32 freq, uint32 numOcc, double stdLen, uint32 *occurrences) {
	if(type == BAI32ItemSetType)
		return new BAI32ItemSet(set, setlen, abetlen, cnt, freq, numOcc, stdLen, occurrences);
	else if(type == Uint16ItemSetType)
		return new Uint16ItemSet(set, setlen, cnt, freq, numOcc, stdLen, occurrences);
	else if(type == BM128ItemSetType)
		return new BM128ItemSet(set, setlen, cnt, freq, numOcc, stdLen, occurrences);
	throw string("Wrong ItemSetType.");
}
ItemSet *ItemSet::CreateSingleton(ItemSetType type, uint32 elem, uint32 abetlen, uint32 cnt, uint32 freq, uint32 numOcc, double stdLen, uint32 *occurrences) {
	if(type == BAI32ItemSetType)
		return new BAI32ItemSet(elem, abetlen, cnt, freq, numOcc, stdLen, occurrences);
	else if(type == Uint16ItemSetType)
		return new Uint16ItemSet(elem, cnt, freq, numOcc, stdLen, occurrences);
	else if(type == BM128ItemSetType)
		return new BM128ItemSet(elem, cnt, freq, numOcc, stdLen, occurrences);
	throw string("Wrong ItemSetType.");
}
ItemSet *ItemSet::CreateEmpty(ItemSetType type, size_t abetlen, uint32 cnt, uint32 freq, uint32 numOcc, double stdLen, uint32 *occurrences) {
	if(type == BAI32ItemSetType)
		return new BAI32ItemSet((uint32) abetlen, cnt, freq, numOcc, stdLen, occurrences);
	else if(type == Uint16ItemSetType)
		return new Uint16ItemSet(cnt, freq, numOcc, stdLen, occurrences);
	else if(type == BM128ItemSetType)
		return new BM128ItemSet(cnt, freq, numOcc, stdLen, occurrences);
	throw string("Wrong ItemSetType.");
}

uint32 ItemSet::MemUsage(const ItemSetType type, const uint32 abLen, const uint32 setLen) {
	if(type == BAI32ItemSetType)
		return BAI32ItemSet::MemUsage(abLen);
	else if(type == Uint16ItemSetType)
		return Uint16ItemSet::MemUsage(setLen);
	else if(type == BM128ItemSetType)
		return BM128ItemSet::MemUsage();
	throw string("Wrong ItemSetType.");
}
uint32 ItemSet::MemUsage(Database *db) {
	ItemSetType type = db->GetDataType();
	if(type == BAI32ItemSetType)
		return BAI32ItemSet::MemUsage((uint32)db->GetAlphabetSize());
	else if(type == Uint16ItemSetType)
		return Uint16ItemSet::MemUsage(db->GetMaxSetLength());
	else if(type == BM128ItemSetType)
		return BM128ItemSet::MemUsage();
	throw string("Wrong ItemSetType.");
}

ItemSetType ItemSet::StringToType(const string desc) {
	if(desc.compare("uint16") == 0)
		return Uint16ItemSetType;
	else if(desc.compare("bai32") == 0)
		return BAI32ItemSetType;
	else if(desc.compare("bm128") == 0)
		return BM128ItemSetType;
	return NoneItemSetType;
}
string ItemSet::TypeToString(const ItemSetType type) {
	if(type == BAI32ItemSetType)
		return "bai32";
	else if(type == Uint16ItemSetType)
		return "uint16";
	else if(type == BM128ItemSetType)
		return "bm128";
	return "ufo";
}

string ItemSet::TypeToFullName(const ItemSetType type) {
	if(type == BAI32ItemSetType)
		return "32bit bitmap array";
	else if(type == Uint16ItemSetType)
		return "uint16 value arrays";
	else if(type == BM128ItemSetType)
		return "128bit bitmap";
	return "aliens";
}

void ItemSet::SetDBOccurrence(uint32 *dbRows, uint32 num) {
	delete[] mDBOccurrence;
	mDBOccurrence = dbRows;
	mNumDBOccurs = num;
	delete[] mUsage;
	mUsage = new uint32[mNumDBOccurs];
	mNumUsages = 0;
	delete[] mPrevUsage;
	mPrevUsage = new uint32[mNumDBOccurs];
	mNumPrevUsages = 0;
}

void ItemSet::SetUsage(uint32 *dbRows, uint32 num) {
	//copy(dbRows, dbRows + num, mUsage);
	memcpy(mUsage, dbRows, num * sizeof(uint32));
	mNumUsages = num;
}

uint32* ItemSet::GetDBOccurrence() {
	return mDBOccurrence;
}

uint32 ItemSet::GetNumDBOccurs() {
	return mNumDBOccurs;
}
void ItemSet::DetermineDBOccurence(Database *db, bool calcNumOcc /* = true */) {
	db->DetermineOccurrences(this,calcNumOcc);
}


uint32*	ItemSet::GetCSUsages()	const {
	return mUsage;
}
uint32*	ItemSet::GetPrevCSUsages()	const {
	return mPrevUsage;
}

ItemSet* ItemSet::Remainder(ItemSet *is) const {
	ItemSet *retval = this->Clone();
	retval->Remove(is);
	return retval;
}

void ItemSet::SortItemSetArray(ItemSet **itemSetArray, uint32 numItemSets, IscOrderType desiredOrder) {
	if(desiredOrder == RandomIscOrder) {
		RandomUtils::PermuteArray(itemSetArray, numItemSets);
	} else if(desiredOrder != NoneIscOrder && numItemSets > 0) {
		ItemSetCollection::MergeSort(itemSetArray, numItemSets, ItemSetCollection::GetCompareFunction(desiredOrder));
	}
}

ItemSet** ItemSet::ConvertItemSetListToArray(islist *isl) {
	ItemSet **iarray = new ItemSet*[isl->size()];

	uint32 cur = 0;
	islist::iterator iend = isl->end(), icur;
	for(icur = isl->begin(); icur != iend; ++icur) {
		iarray[cur++] = (ItemSet*) (*icur);
	}
	return iarray;
}

int8 ItemSet::CmpSupport(const ItemSet *b) const {
	if(mSupport > b->mSupport)
		return 1;
	else if(mSupport < b->mSupport)
		return -1;
	else 
		return 0;
}

int8 ItemSet::CmpArea(ItemSet *b) {
	uint32 me = (mSupport * GetLength());
	uint32 he = (b->mSupport * b->GetLength());
	if(me > he)
		return 1;
	else if(me < he)
		return -1;
	else
		return 0;
}

void ItemSet::UpdateDBOccurrencesAfterUnion(const ItemSet* i, const ItemSet* j, ItemSet* result) {
	// old, koen-ware
	if(true) {
		vector<uint32> tmpDBOccurrence(min(i->mNumDBOccurs, j->mNumDBOccurs));
		vector<uint32>::iterator it;

		it = set_intersection(i->mDBOccurrence, i->mDBOccurrence + i->mNumDBOccurs, j->mDBOccurrence, j->mDBOccurrence + j->mNumDBOccurs, tmpDBOccurrence.begin());

		if (result->mDBOccurrence) {
			delete[] result->mDBOccurrence;
			result->mDBOccurrence = NULL;
		}
		if (result->mUsage) {
			delete[] result->mUsage;
			result->mUsage = NULL;
		}
		if (result->mPrevUsage) {
			delete[] result->mPrevUsage;
			result->mPrevUsage = NULL;
		}

		result->mNumDBOccurs = uint32(it - tmpDBOccurrence.begin());
		result->mDBOccurrence = new uint32[result->mNumDBOccurs];
		copy(tmpDBOccurrence.begin(), it, result->mDBOccurrence);

		result->mUsage = new uint32[result->mNumDBOccurs];
		result->mPrevUsage = new uint32[result->mNumDBOccurs];
		result->mNumUsages = 0;
		result->mNumPrevUsages = 0;
	} else
	// new jv-ware
	{
		uint32 *tmpDBOccs = new uint32[min(i->mNumDBOccurs, j->mNumDBOccurs)]; // intersection, so always <=
		uint32 *oi = i->mDBOccurrence, *oj = j->mDBOccurrence;
		uint32 ni = i->mNumDBOccurs, nj = j->mNumDBOccurs;
		uint32 ci = 0, cj = 0, ck = 0;
		while(ci<ni && cj<nj) {
			if(oi[ci]==oj[cj]) {
				tmpDBOccs[ck++] = oi[ci];
				ci++; cj++;
			} else if(oi[ci] < oj[cj]) {
				ci++;
			} else {
				cj++;
			}
		} // intersection of oi and oj now in tmpDBOccs, length thereof in ck

		// Save into result
		if(result->mDBOccurrence == NULL || result->mNumDBOccurs < ck) {
			if(result->mUsage)	delete[] result->mUsage;
			result->mUsage = new uint32[result->mNumDBOccurs];

			if(result->mPrevUsage)	delete[] result->mPrevUsage;
			result->mPrevUsage = new uint32[result->mNumDBOccurs];
		} // else no need to re-allocate usage and prevusage arrays.

		result->mNumUsages = 0;
		result->mNumPrevUsages = 0;
		result->mNumDBOccurs = ck;

		if(result->mDBOccurrence != NULL)
			delete[] result->mDBOccurrence;
		result->mDBOccurrence = tmpDBOccs; // a bit too large, but fsck it.
	}


	// jv says: dunno what this is:

	// Best-case estimate of future usage?
//	uint32 x, y, z;
//	for (x = y = z = 0; x < result->mNumDBOccurs; ++x) {
//		while (result->mDBOccurrence[x] != i->mDBOccurrence[y]) ++y;
//		while (result->mDBOccurrence[x] != j->mDBOccurrence[z]) ++z;
//		result->mUsageFlags[x] = (i->mUsageFlags[y] && j->mUsageFlags[z]);
//		result->mUsageCount += result->mUsageFlags[x];
//		result->mPrevUsageFlags[x] = (i->mPrevUsageFlags[y] && j->mPrevUsageFlags[z]);
//		result->mPrevUsageCount += result->mPrevUsageFlags[x];
//	}
}

void ItemSet::SetAllUsed() {
	mNumUsages = mNumDBOccurs;
	memcpy(mUsage, mDBOccurrence, mNumUsages * sizeof(uint32));
}

void ItemSet::SetAllUnused() {
	mNumUsages = 0;
}

void ItemSet::SetUsed(uint32 tid) {
	if (!mNumUsages) {
		mUsage[0] = tid;
	} else {
		uint32* p = mUsage + ArrayUtils::BinarySearchInsertionLocationAsc(tid, mUsage, mNumUsages);
		//uint32* p = std::upper_bound(mUsage, mUsage + mNumUsages, tid);
		memmove(p + 1, p, (mNumUsages - (p - mUsage)) * sizeof(uint32));
		*p = tid;
	}
	++mNumUsages;
}



void ItemSet::SetUnused(uint32 tid) {
	if (mNumUsages > 1 && mUsage[mNumUsages - 1] != tid) {
		uint32* p = mUsage + 1 + ArrayUtils::BinarySearchAsc(tid, mUsage, mNumUsages);
		//uint32* p = std::upper_bound(mUsage, mUsage + mNumUsages, tid);
		memmove(p - 1, p, (mNumUsages - (p - mUsage)) * sizeof(uint32));
	}
	if (mNumUsages >= 1)
		--mNumUsages;
}

uint32 ItemSet::CountUsageMatches(const ItemSet* is) const {
	uint32 counter = 0;
	uint32* first1 = mUsage;
	uint32* first2 =is->mUsage;
	uint32* last1 = mUsage + mNumUsages;
	uint32* last2 = is->mUsage + is->mNumUsages;
	while (first1 != last1 && first2 != last2)
	{
		if (*first1 < *first2) ++first1;
		else if (*first2 < *first1) ++first2;
		else { ++counter; ++first1; ++first2; }
	}
	return counter;
}

