//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
// 
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
#ifndef __ARRAYUTILS
#define __ARRAYUTILS

#include "QtilsApi.h"

#if defined (__GNUC__) && defined (__unix__)
#include <cstring>
#endif // defined (__GNUC__) && defined (__unix__)


/** A util class to do funky array stuffs */
class QTILS_API ArrayUtils {
public:

	template <class T> __inline static void Swap(T* arr, uint32 a, uint32 b);
	// inserts element `val` into `arr` at `pos`. numVals keeps track of number of used cells in `arr`, `arrSize` of the maximum number of elements. `minimalGrowth`, if enabled, if necessary, returns a new array of arrSize+1 instead of arrSize*2 
	template <class T> __inline static void Insert(T val, uint32 pos, T* &arr, uint32 &numVals, uint32 &arrSize, bool minimalGrowth = true);
	// removes the element of `arr` at index `pos`. numVals keeps track of number of used cells in `arr`, `arrSize` of the maximum number of elements. `resizeArray`, if enabled, returns a new array of arrSize-1 instead of leaving `arrSize` as is. 
	template <class T> __inline static void Remove(uint32 pos, T* &arr, uint32 &numVals, uint32& arrSize, bool resizeArray /* = true */);

	template <class T> static void Permute(T* arr, uint32* idxs, uint32 len);

	template <class T> static uint32 BinarySearchAsc(T val, T* arr, uint32 arrLen);
  template <class T> static uint32 BinarySearchMayNotExistAsc(T val, T* arr, uint32 arrLen);

	// looks for the insertion position for `val` in `arr`. 
	// returns first index where `val` could be inserted, but arr[idx] could be `val' already
	template <class T> static uint32 BinarySearchInsertionLocationAsc(T val, T* arr, uint32 arrLen);


	// sorts array `arr` of length `arrLen` ascendingly
	template <class T> static void BSortAsc(T* arr, uint32 arrLen);

	// sorts array `arr` of length `arrLen` descendingly
	template <class T> static void BSortDesc(T* arr, uint32 arrLen);

	// sorts array `arr` of pointers, of length `arrLen` ascendingly, comparing *arr[i] > *arr[j] (and not the pointers!)
	template <class T> static void BSortAsc(T** arr, uint32 arrLen);

	// sorts array `arr` of pointers, of length `arrLen` descendingly, comparing *arr[i] > *arr[j] (and not the pointers!)
	template <class T> static void BSortDesc(T** arr, uint32 arrLen);

	// sorts array `arr` of length `arrLen` ascendingly, keeping track of the original indici in (filled by you) `origIdxArr`
	template <class T, class R> static void BSortAsc(T* arr, uint32 arrLen, R* origIdxArr);

	// sorts array `arr` of length `arrLen` descendingly, keeping track of the original indici in (filled by you) `origIdxArr`
	template <class T, class R> static void BSortDesc(T* arr, uint32 arrLen, R* origIdxArr);

	// sorts array `arr` of length `arrLen` ascendingly, keeping track of the original indici in (filled by you) `origIdxArr`
	template <class T, class R> static void BSortAsc(T** arr, uint32 arrLen, R* origIdxArr);


	//////////////////////////////////////////////////////////////////////////
	// Quick-sort
	//////////////////////////////////////////////////////////////////////////

	// sorts (in place, -not- stable) `arr` of length `arrLen` ascendingly. 
	template <class T> static void QSortAsc(T* arr, int32 arrLen);
	// sorts (in place, -not- stable) `arr` ascendingly between indici `left` and `right`. 
	template <class T> static void QSortAsc(T* arr, int32 left, int32 right);
	// sorts (in place, -not- stable) `arr` of length `arrLen` ascendingly, keeping track of the original indici in (filled by you) `origIdxArr`
	template <class T, class R> static void QSortAsc(T* arr, int32 arrLen, R* origIdxArr);
	// sorts (in place, -not- stable) `arr` ascendingly between indici `left` and `right`, keeping track of the original indici in (filled by you) `origIdxArr`
	template <class T, class R> static void QSortAsc(T* arr, int32 from, int32 to, R* origIdxArr);

	//////////////////////////////////////////////////////////////////////////
	// Merge-sort
	//////////////////////////////////////////////////////////////////////////

	template <class T, class R> static void InitMergeSort(uint32 maxArrLen, bool idxArr); 
	static void CleanUpMergeSort();

	template <class T> static void MSortAsc(T *arr, uint32 arrLen);
	template <class T> static void MSortDesc(T *arr, uint32 arrLen);
	template <class T, class R> static void MSortAsc(T *arr, uint32 arrLen, R* origIdxArr);
	template <class T, class R> static void MSortDesc(T *arr, uint32 arrLen, R* origIdxArr);


protected:
	//////////////////////////////////////////////////////////////////////////
	// Merge Sort Helper Functions
	//////////////////////////////////////////////////////////////////////////
	template <class T> static void MSortAscMerge(T *arr, uint32 lo, uint32 m, uint32 hi, T* mergeSortAuxArr);
	template <class T> static void MSortAscSort(T *arr, uint32 lo, uint32 hi, T* mergeSortAuxArr);

	template <class T> static void MSortDescMerge(T *arr, uint32 lo, uint32 m, uint32 hi, T* mergeSortAuxArr);	
	template <class T> static void MSortDescSort(T *arr, uint32 lo, uint32 hi, T* mergeSortAuxArr);

	template <class T, class R> static void MSortAscMerge(T *arr, uint32 lo, uint32 m, uint32 hi, T* mergeSortAuxArr, R* idxArr, R* idxAuxArr);
	template <class T, class R> static void MSortAscSort(T *arr, uint32 lo, uint32 hi, T* mergeSortAuxArr, R* idxArr, R* idxAuxArr);

	template <class T, class R> static void MSortDescMerge(T *arr, uint32 lo, uint32 m, uint32 hi, T* mergeSortAuxArr, R* idxArr, R* idxAuxArr);
	template <class T, class R> static void MSortDescSort(T *arr, uint32 lo, uint32 hi, T* mergeSortAuxArr, R* idxArr, R* idxAuxArr);

	static void* sMergeSortAuxArr;
	static void* sMergeSortIdxAuxArr;

	static size_t sMergeSortAuxArrNumBytes;
	static size_t sMergeSortIdxAuxArrNumBytes;

	//////////////////////////////////////////////////////////////////////////
	// Quick Sort Helper Functions
	//////////////////////////////////////////////////////////////////////////

};


#if defined (__GNUC__) && (defined (__unix__) || (defined (__APPLE__) && defined (__MACH__)))
#define __inline /*__inline*/
#define static /*static*/
#endif


template <class T> __inline static void ArrayUtils::Swap(T* arr, uint32 a, uint32 b) {
	T tmp = arr[a];
	arr[a] = arr[b];
	arr[b] = tmp;
}

// sorts array `arr` of length `arrLen` ascendingly
template <class T> static void ArrayUtils::BSortAsc(T* arr, uint32 arrLen) {
	// bubble-sort
	for(uint32 i=1; i<arrLen; i++) {
		for(uint32 j=0; j<arrLen-i; j++) {
			if(arr[j] > arr[j+1]) {
				T tmp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = tmp;
			}
		}
	}
}
// sorts array `arr` of length `arrLen` ascendingly
template <class T> static void ArrayUtils::BSortAsc(T** arr, uint32 arrLen) {
	// bubble-sort
	for(uint32 i=1; i<arrLen; i++) {
		for(uint32 j=0; j<arrLen-i; j++) {
			if(*arr[j] > *arr[j+1]) {
				T* tmp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = tmp;
			}
		}
	}
}

// sorts array `arr` of length `arrLen` ascendingly, keeping track of the original indici in (filled by you) `origIdxArr`
template <class T, class R> static void ArrayUtils::BSortAsc(T* arr, uint32 arrLen, R* origIdxArr) {
	// bubble-sort
	for(uint32 i=1; i<arrLen; i++) {
		for(uint32 j=0; j<arrLen-i; j++) {
			if(arr[j] > arr[j+1]) {
				T tmp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = tmp;
				R swap = origIdxArr[j];
				origIdxArr[j]=origIdxArr[j+1];
				origIdxArr[j+1]=swap;
			}
		}
	}
}
// sorts array `arr` of length `arrLen` ascendingly, keeping track of the original indici in (filled by you) `origIdxArr`
template <class T, class R> static void ArrayUtils::BSortAsc(T** arr, uint32 arrLen, R* origIdxArr) {
	// bubble-sort
	for(uint32 i=1; i<arrLen; i++) {
		for(uint32 j=0; j<arrLen-i; j++) {
			if(*arr[j] > *arr[j+1]) {
				T* tmp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = tmp;
				R swap = origIdxArr[j];
				origIdxArr[j]=origIdxArr[j+1];
				origIdxArr[j+1]=swap;
			}
		}
	}
}

// sorts array `arr` of length `arrLen` descendingly
template <class T> static void ArrayUtils::BSortDesc(T* arr, uint32 arrLen) {
	// bubble-sort
	for(uint32 i=1; i<arrLen; i++) {
		for(uint32 j=0; j<arrLen-i; j++) {
			if(arr[j] < arr[j+1]) {
				T tmp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = tmp;
			}
		}
	}
}
// sorts array `arr` of length `arrLen` descendingly
template <class T> static void ArrayUtils::BSortDesc(T** arr, uint32 arrLen) {
	// bubble-sort
	for(uint32 i=1; i<arrLen; i++) {
		for(uint32 j=0; j<arrLen-i; j++) {
			if(*arr[j] < *arr[j+1]) {
				T* tmp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = tmp;
			}
		}
	}
}

// sorts array `arr` of length `arrLen` descendingly, keeping track of the original indici in (filled by you) `origIdxArr`
template <class T, class R> static void ArrayUtils::BSortDesc(T* arr, uint32 arrLen, R* origIdxArr) {
	// bubble-sort
	for(uint32 i=1; i<arrLen; i++) {
		for(uint32 j=0; j<arrLen-i; j++) {
			if(arr[j] < arr[j+1]) {
				T tmp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = tmp;
				R swap = origIdxArr[j];
				origIdxArr[j]=origIdxArr[j+1];
				origIdxArr[j+1]=swap;
			}
		}
	}	
}

template <class T, class R> static void ArrayUtils::InitMergeSort(uint32 maxArrLen, bool idxArr) {
	if(sMergeSortAuxArr != NULL)
		THROW("Clean me up before you go go.")
	size_t mergeSortAuxArrLen = (maxArrLen+1)/2;
	sMergeSortAuxArr = new T[mergeSortAuxArrLen];
	sMergeSortAuxArrNumBytes = mergeSortAuxArrLen * sizeof(T);
	if(idxArr == true) {
		if(sMergeSortIdxAuxArr != NULL)
			THROW("Clean me up before you go go.")
		size_t mergeSortIdxAuxArrLen = (maxArrLen+1)/2;
		sMergeSortIdxAuxArr = new R[mergeSortIdxAuxArrLen];
		sMergeSortIdxAuxArrNumBytes = mergeSortIdxAuxArrLen * sizeof(R);
	}
}

template <class T> static void ArrayUtils::MSortAsc(T *arr, uint32 arrLen) {
	if(arrLen == 0)
		return;
	bool freshArray = false;
	size_t mergeSortAuxArrReqLen = (arrLen+1)/2;
	if(sMergeSortAuxArr == NULL) {
		sMergeSortAuxArr = new T[mergeSortAuxArrReqLen];
		sMergeSortAuxArrNumBytes = mergeSortAuxArrReqLen * sizeof(T);
		freshArray = true;
	} else if(sMergeSortAuxArrNumBytes < sizeof(T) * mergeSortAuxArrReqLen) {
		THROW("We need a bigger boat!");
	}

	MSortAscSort(arr, 0, arrLen-1, (T*)sMergeSortAuxArr);
	if(freshArray) {
		delete[] sMergeSortAuxArr;
		sMergeSortAuxArr = NULL;
		sMergeSortAuxArrNumBytes = 0;
	}
}

template <class T, class R> static void ArrayUtils::MSortAsc(T *arr, uint32 arrLen, R* origIdxArr) {
	if(arrLen == 0)
		return;
	bool freshAuxArray = false, freshIdxAuxArray = false;
	size_t mergeSortAuxArrReqLen = (arrLen+1)/2;
	if(sMergeSortAuxArr == NULL) {
		sMergeSortAuxArr = new T[mergeSortAuxArrReqLen];
		sMergeSortAuxArrNumBytes = mergeSortAuxArrReqLen * sizeof(T);
		freshAuxArray = true;
	} else if(sMergeSortAuxArrNumBytes < sizeof(T) * mergeSortAuxArrReqLen)
		THROW("We need a bigger boat!")
	if(sMergeSortIdxAuxArr == NULL) {
		sMergeSortIdxAuxArr = new R[mergeSortAuxArrReqLen];
		sMergeSortIdxAuxArrNumBytes = mergeSortAuxArrReqLen * sizeof(R);
		freshIdxAuxArray = true;
	} else if(sMergeSortIdxAuxArrNumBytes < sizeof(R) * mergeSortAuxArrReqLen)
		THROW("We need a bigger boat!")

	MSortAscSort(arr, 0, arrLen-1, (T*) sMergeSortAuxArr, origIdxArr, (R*) sMergeSortIdxAuxArr);
	if(freshAuxArray) {
		delete[] sMergeSortAuxArr;
		sMergeSortAuxArr = NULL;
		sMergeSortAuxArrNumBytes = 0;
	}
	if(freshIdxAuxArray) {
		delete[] sMergeSortIdxAuxArr;
		sMergeSortIdxAuxArr = NULL;
		sMergeSortIdxAuxArrNumBytes = 0;
	}
}
template <class T> static void ArrayUtils::MSortDesc(T *arr, uint32 arrLen) {
	if(arrLen == 0)
		return;
	bool freshArray = false;
	size_t mergeSortAuxArrReqLen = (arrLen+1)/2;
	if(sMergeSortAuxArr == NULL) {
		size_t mergeSortAuxArrLen = (arrLen+1)/2;
		sMergeSortAuxArr = new T[mergeSortAuxArrLen];
		sMergeSortAuxArrNumBytes = mergeSortAuxArrLen * sizeof(T);
		freshArray = true;
	} else if(sMergeSortAuxArrNumBytes < sizeof(T) * mergeSortAuxArrReqLen)
		THROW("We need a bigger boat!")
		MSortDescSort(arr, 0, arrLen-1, (T*) sMergeSortAuxArr);
	if(freshArray) {
		delete[] sMergeSortAuxArr;
		sMergeSortAuxArr = NULL;
		sMergeSortAuxArrNumBytes = 0;
	}
}
template <class T, class R> static void ArrayUtils::MSortDesc(T *arr, uint32 arrLen, R* origIdxArr) {
	if(arrLen == 0)
		return;
	bool freshAuxArray = false, freshIdxAuxArray = false;
	size_t mergeSortAuxArrReqLen = (arrLen+1)/2;
	if(sMergeSortAuxArr == NULL) {
		sMergeSortAuxArr = new T[mergeSortAuxArrReqLen];
		sMergeSortAuxArrNumBytes = mergeSortAuxArrReqLen * sizeof(T);
		freshAuxArray = true;
	} else if(sMergeSortAuxArrNumBytes < sizeof(T) * mergeSortAuxArrReqLen)
		THROW("We need a bigger boat!")
		if(sMergeSortIdxAuxArr == NULL) {
			sMergeSortIdxAuxArr = new R[mergeSortAuxArrReqLen];
			sMergeSortIdxAuxArrNumBytes = mergeSortAuxArrReqLen * sizeof(R);
			freshIdxAuxArray = true;
		} else if(sMergeSortIdxAuxArrNumBytes < sizeof(R) * mergeSortAuxArrReqLen)
			THROW("We need a bigger boat!")
			MSortDescSort(arr, 0, arrLen-1, (T*) sMergeSortAuxArr, origIdxArr, (R*) sMergeSortIdxAuxArr);
		if(freshAuxArray) {
			delete[] sMergeSortAuxArr;
			sMergeSortAuxArr = NULL;
			sMergeSortAuxArrNumBytes = 0;
		}
		if(freshIdxAuxArray) {
			delete[] sMergeSortIdxAuxArr;
			sMergeSortIdxAuxArr = NULL;
			sMergeSortIdxAuxArrNumBytes = 0;
		}
}

template <class T> static uint32 ArrayUtils::BinarySearchAsc(T val, T* arr, uint32 arrLen) {
	uint32 minIdx = 0;
	uint32 maxIdx = arrLen-1;
	uint32 tstIdx = 0;
	bool found = false;
	while(minIdx <= maxIdx) {
		tstIdx = minIdx + (maxIdx - minIdx)/2;
		if(arr[tstIdx] > val) {
			maxIdx = tstIdx - 1;
			if(maxIdx > arrLen)
				return UINT32_MAX_VALUE;
		} else if(arr[tstIdx] < val) {
			minIdx = tstIdx + 1;
			if(minIdx > arrLen)
				return minIdx;
		} else {
			return tstIdx;
		}
	}
	return UINT32_MAX_VALUE;
}

template <class T> static uint32 ArrayUtils::BinarySearchMayNotExistAsc(T val, T* arr, uint32 arrLen) {
		uint32 minIdx = 0;
		uint32 maxIdx = arrLen-1;
		uint32 tstIdx = UINT32_MAX_VALUE;
		bool found = false;
		while(minIdx+1 < maxIdx) { // while there are at least 3 possibilities
			tstIdx = minIdx + (maxIdx - minIdx)/2;
			if(arr[tstIdx] > val) {
				maxIdx = tstIdx - 1;
			} else if(arr[tstIdx] < val) {
				minIdx = tstIdx + 1;
			} else {
				return tstIdx;
			}
		}
		if(arr[minIdx] == val)
			return minIdx;
		if(arr[maxIdx] == val)
			return maxIdx;
		return UINT32_MAX_VALUE; // not found
	}

// looks for the insertion position for `val` in `arr`. 
// returns first index where `val` could be inserted, but arr[idx] could be `val' already
template <class T> static uint32 ArrayUtils::BinarySearchInsertionLocationAsc(T val, T* arr, uint32 arrLen) {
	uint32 minIdx = 0;
	uint32 maxIdx = arrLen-1;
	uint32 tstIdx = 0;
	bool found = false;
	while(minIdx <= maxIdx) {
		tstIdx = minIdx + (maxIdx - minIdx)/2;
		if(arr[tstIdx] > val) {
			maxIdx = tstIdx - 1;
			if(maxIdx > arrLen)
				return 0;
		} else if(arr[tstIdx] < val) {
			minIdx = tstIdx + 1;
		} else {
			return tstIdx;
		}
	}
	return max(minIdx,maxIdx);
}

template <class T> static void ArrayUtils::MSortAscMerge(T *arr, uint32 lo, uint32 m, uint32 hi, T* mergeSortAuxArr) {
	uint32 i, j, k;
	// copy first half of array a to auxiliary array b
	// i=0; j=lo; while (j<=m) mergeSortAuxArr[i++]=arr[j++];
	memcpy(mergeSortAuxArr,arr+lo,sizeof(T)*(m-lo+1));
	j=m+1;

	i=0; k=lo;
	// copy back next-greatest element at each time
	while (k<j && j<=hi)
		if (mergeSortAuxArr[i] < arr[j])
			arr[k++]=mergeSortAuxArr[i++];
		else
			arr[k++]=arr[j++];

	// copy back remaining elements of first half (if any)
	//	while (k<j)	arr[k++]=mergeSortAuxArr[i++];
	memcpy(arr+k,mergeSortAuxArr+i,sizeof(T)*(j-k));
}

template <class T> static void ArrayUtils::MSortAscSort(T *arr, uint32 lo, uint32 hi, T* mergeSortAuxArr) {
	if(lo<hi) {
		uint32 m = (lo+hi)/2;
		MSortAscSort(arr, lo, m, mergeSortAuxArr);
		MSortAscSort(arr, m+1, hi, mergeSortAuxArr);
		MSortAscMerge(arr, lo, m, hi, mergeSortAuxArr);
	}
}

template <class T, class R> static void ArrayUtils::MSortAscMerge(T *arr, uint32 lo, uint32 m, uint32 hi, T* mergeSortAuxArr, R* idxArr, R* idxAuxArr) {
	uint32 i, j, k;
	// copy first half of array a to auxiliary array b
	// i=0; j=lo; while (j<=m) mergeSortAuxArr[i++]=arr[j++];
	memcpy(mergeSortAuxArr,arr+lo,sizeof(T)*(m-lo+1));
	memcpy(idxAuxArr,idxArr+lo,sizeof(R)*(m-lo+1));
	j=m+1;

	i=0; k=lo;
	// copy back next-greatest element at each time
	while (k<j && j<=hi) {
		if (mergeSortAuxArr[i] < arr[j]) {
			idxArr[k]=idxAuxArr[i];
			arr[k++]=mergeSortAuxArr[i++];
		} else {
			idxArr[k]=idxArr[j];
			arr[k++]=arr[j++];
		}
	}

	// copy back remaining elements of first half (if any)
	//	while (k<j)	arr[k++]=mergeSortAuxArr[i++];
	memcpy(arr+k,mergeSortAuxArr+i,sizeof(T)*(j-k));
	memcpy(idxArr+k,idxAuxArr+i,sizeof(R)*(j-k));
}
template <class T, class R> static void ArrayUtils::MSortAscSort(T *arr, uint32 lo, uint32 hi, T* mergeSortAuxArr, R* idxArr, R* idxAuxArr) {
	if(lo<hi) {
		uint32 m = (lo+hi)/2;
		MSortAscSort(arr, lo, m, mergeSortAuxArr, idxArr, idxAuxArr);
		MSortAscSort(arr, m+1, hi, mergeSortAuxArr, idxArr, idxAuxArr);
		MSortAscMerge(arr, lo, m, hi, mergeSortAuxArr, idxArr, idxAuxArr);
	}
}

//static void MSortDescAux(uint32 *arr, uint32 arrLen, uint32 *auxArray /* auxiliary array of length arrLen+1/2 */ );
template <class T> static void ArrayUtils::MSortDescMerge(T *arr, uint32 lo, uint32 m, uint32 hi, T* mergeSortAuxArr) {
	uint32 i, j, k;
	// copy first half of array a to auxiliary array b
	// i=0; j=lo; while (j<=m) mergeSortAuxArr[i++]=arr[j++];
	memcpy(mergeSortAuxArr,arr+lo,sizeof(T)*(m-lo+1));
	j=m+1;

	i=0; k=lo;
	// copy back next-greatest element at each time
	while (k<j && j<=hi)
		if (mergeSortAuxArr[i] > arr[j])
			arr[k++]=mergeSortAuxArr[i++];
		else
			arr[k++]=arr[j++];

	// copy back remaining elements of first half (if any)
	//	while (k<j)	arr[k++]=mergeSortAuxArr[i++];
	memcpy(arr+k,mergeSortAuxArr+i,sizeof(T)*(j-k));

}
template <class T> static void ArrayUtils::MSortDescSort(T *arr, uint32 lo, uint32 hi, T* mergeSortAuxArr) {
	if(lo<hi) {
		uint32 m = (lo+hi)/2;
		MSortDescSort(arr, lo, m, mergeSortAuxArr);
		MSortDescSort(arr, m+1, hi, mergeSortAuxArr);
		MSortDescMerge(arr, lo, m, hi, mergeSortAuxArr);
	}
}

template <class T, class R> static void ArrayUtils::MSortDescMerge(T *arr, uint32 lo, uint32 m, uint32 hi, T* mergeSortAuxArr, R* idxArr, R* idxAuxArr) {
	uint32 i, j, k;
	// copy first half of array a to auxiliary array b
	// i=0; j=lo; while (j<=m) mergeSortAuxArr[i++]=arr[j++];
	memcpy(mergeSortAuxArr,arr+lo,sizeof(T)*(m-lo+1));
	memcpy(idxAuxArr,idxArr+lo,sizeof(R)*(m-lo+1));
	j=m+1;

	i=0; k=lo;
	// copy back next-greatest element at each time
	while (k<j && j<=hi) {
		if (mergeSortAuxArr[i] > arr[j]) {
			idxArr[k]=idxAuxArr[i];
			arr[k++]=mergeSortAuxArr[i++];
		} else {
			idxArr[k]=idxArr[j];
			arr[k++]=arr[j++];
		}
	}

	// copy back remaining elements of first half (if any)
	//	while (k<j)	arr[k++]=mergeSortAuxArr[i++];
	memcpy(arr+k,mergeSortAuxArr+i,sizeof(T)*(j-k));
	memcpy(idxArr+k,idxAuxArr+i,sizeof(R)*(j-k));
}

template <class T, class R> static void ArrayUtils::MSortDescSort(T *arr, uint32 lo, uint32 hi, T* mergeSortAuxArr, R* idxArr, R* idxAuxArr) {
	if(lo<hi) {
		uint32 m = (lo+hi)/2;
		MSortDescSort(arr, lo, m, mergeSortAuxArr, idxArr, idxAuxArr);
		MSortDescSort(arr, m+1, hi, mergeSortAuxArr, idxArr, idxAuxArr);
		MSortDescMerge(arr, lo, m, hi, mergeSortAuxArr, idxArr, idxAuxArr);
	}
}

template <class T> static void ArrayUtils::QSortAsc(T* arr, int32 arrLen) {
	if(arrLen > 1)
		QSortAsc(arr, 0, arrLen-1);
}
template <class T> static void ArrayUtils::QSortAsc(T* arr, int32 left, int32 right) {
	int pivot, leftIdx = left, rightIdx = right;
	if(right - left > 0) {
		pivot = (left + right) / 2;
		while(leftIdx <= pivot && rightIdx >= pivot) {
			while(arr[leftIdx] < arr[pivot] && leftIdx <= pivot)
				leftIdx = leftIdx + 1;
			while(arr[rightIdx] > arr[pivot] && rightIdx >= pivot)
				rightIdx = rightIdx - 1;
			ArrayUtils::Swap(arr, leftIdx, rightIdx);
			leftIdx = leftIdx+1;
			rightIdx = rightIdx-1;
			if(leftIdx-1 == pivot) {
				rightIdx = rightIdx + 1;
				pivot = rightIdx;
			} else if(rightIdx + 1 == pivot) {
				leftIdx = leftIdx - 1;
				pivot = leftIdx;
			}
		}
		ArrayUtils::QSortAsc(arr, left, pivot-1);
		ArrayUtils::QSortAsc(arr, pivot+1, right);
	}
}

template <class T, class R> static void ArrayUtils::QSortAsc(T* arr, int32 arrLen, R* idxArr) {
	if(arrLen > 1)
		QSortAsc(arr, 0, arrLen-1, idxArr);
}
template <class T, class R> static void ArrayUtils::QSortAsc(T* arr, int32 left, int32 right, R* idxArr) {
	int pivot, leftIdx = left, rightIdx = right;
	if(right - left > 0) {
		pivot = (left + right) / 2;
		while(leftIdx <= pivot && rightIdx >= pivot) {
			while(arr[leftIdx] < arr[pivot] && leftIdx <= pivot)
				leftIdx = leftIdx + 1;
			while(arr[rightIdx] > arr[pivot] && rightIdx >= pivot)
				rightIdx = rightIdx - 1;
			if(leftIdx != rightIdx) {
				ArrayUtils::Swap(arr, leftIdx, rightIdx);
				ArrayUtils::Swap(idxArr, leftIdx, rightIdx);
			}
			leftIdx = leftIdx+1;
			rightIdx = rightIdx-1;
			if(leftIdx-1 == pivot) {
				rightIdx = rightIdx + 1;
				pivot = rightIdx;
			} else if(rightIdx + 1 == pivot) {
				leftIdx = leftIdx - 1;
				pivot = leftIdx;
			}
		}
		ArrayUtils::QSortAsc(arr, left, pivot-1, idxArr);
		ArrayUtils::QSortAsc(arr, pivot+1, right, idxArr);
	}
}

template <class T> __inline static void ArrayUtils::Insert(T val, uint32 pos, T* &arr, uint32 &numVals, uint32 &arrSize, bool minimalGrowth /* = true */) {
	if(numVals + 1 == arrSize) {
		uint32 newArrSize = minimalGrowth == true ? arrSize +1 : arrSize * 2;
		T *tmpArr = new T[newArrSize];
		memcpy(tmpArr, arr, sizeof(T) * pos);
		memcpy(tmpArr + pos + 1, arr + pos, sizeof(T) * (arrSize - pos));
		tmpArr[pos] = val;
		delete[] arr;
		arr = tmpArr;
		arrSize = newArrSize;
	} else {
		memcpy(arr + pos + 1, arr + pos, sizeof(T) * (numVals - pos));
		arr[pos] = val;
	}
	numVals++;
}

template <class T> __inline static void ArrayUtils::Remove(uint32 pos, T* &arr, uint32 &numVals, uint32& arrSize, bool resizeArray /* = true */) {
	if(resizeArray == true) {
		uint32 newArrSize = arrSize - 1;
		T *tmpArr = new T[arrSize-1];
		memcpy_s(tmpArr, newArrSize * sizeof(T), arr, pos * sizeof(T));	// up till idx of val
		memcpy_s(tmpArr+pos, (newArrSize - pos) * sizeof(T), arr+pos+1, sizeof(T) * (numVals - pos - 1)); // from idx of val onward
		delete[] arr;
		arr = tmpArr;
		arrSize--;
	} else {
		memcpy(arr + pos, arr + pos + 1, sizeof(T) * (numVals - pos - 1));
	}
	numVals--;
}

template <class T> static void ArrayUtils::Permute(T* arr, uint32* idxs, uint32 len) {
	T* tmp = new T[len];
	for(uint32 i=0; i<len; i++) {
		tmp[i] = arr[idxs[i]];
	}
	memcpy_s(arr, sizeof(T)*len, tmp, sizeof(T)*len);
	delete[] tmp;
}

#if defined (__GNUC__) && (defined (__unix__) || (defined (__APPLE__) && defined (__MACH__)))
#undef __inline
#undef static
#endif

#endif // __ARRAYUTILS

