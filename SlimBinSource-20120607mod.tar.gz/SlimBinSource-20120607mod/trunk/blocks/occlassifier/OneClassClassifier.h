//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#ifndef __ONECLASSCLASSIFIER_H
#define __ONECLASSCLASSIFIER_H

#include <unordered_map>

#include <Config.h>

// bass
#include <db/ClassedDatabase.h>

// fic
#include "../algo/CodeTable.h"
#include "../algo/StandardCodeTable.h"

enum Inequality {
	Chebyshev = 0,	// Two-sided Chebyshev's inequality
	Cantelli		// One-sided Chebyshev's inequality, aka Cantelli's inequality
};

struct OCCModel {
	double mean;
	double stdev;
	double k;
	double confidence;
	uint32 label;
};

class OneClassClassifier {
public:
	OneClassClassifier(const Config *config);
	~OneClassClassifier();

	void Analyse();
	void Classify();

protected:
	void train(ClassedDatabase *db, CodeTable *ct, OCCModel &model);
	void predict(ClassedDatabase *db, CodeTable *ct, OCCModel model, uint32 **confusion, const string& filename);

	void WriteConfusionFile(const string &filename, uint32 **confusion);
	void WriteCodeLengthsFile(const string &filename, ClassedDatabase *cdb, CodeTable* ct);

	static Inequality StringToInequality(const string& s);

	void coverTransaction(CodeTable* ct, Database* db, ItemSet* transaction, double& codelength, FILE* fp=0);
	void coverTransaction(CodeTable* ct, Database* db, ItemSet* transaction, double& codelength, unordered_map<uint32,double>* codeLenPerItem);

private:
	const Config *mConfig;

	uint32		*mClasses;
	uint32		mNumClasses;
	uint32		mNumFolds;

	Inequality	mInequality;
};

#endif // __ONECLASSCLASSIFIER_H
