//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#ifndef __ALGO_NG_H
#define __ALGO_NG_H

#include "../../algo/Algo.h"

#include <Config.h>

enum HashPolicyType { // specify hash policy
	hashNoCandidates=0,	// 0	n	no check
	hashAllCandidates,	// 1	a	all itemsets previously added
	hashCtCandidates,	// 2	c	only itemsets in current ct		// TODO: still need to be implemented!
};

class Algo_ng: public Algo {

public:

	Algo_ng(CodeTable* ct, HashPolicyType hashPolicy, Config* config);

	virtual string	GetShortName();

	virtual void	SetReportIter(const bool b) { mReportIteration = b; }
	virtual void	SetReportIterStyle(ReportType repIter) { mReportIterType = repIter; }

	void			SetResumeCodeTable(const string& ctFile) { mCTFile = ctFile; }
	void			LoadCodeTable(const string& ctFile);

	void			OpenLogFile();
	void			CloseLogFile();

	/* Static factory method */
	static Algo*	CreateAlgo(const string &algoname, ItemSetType type, Config* config);

	static string	HashPolicyTypeToString(HashPolicyType type);
	static string	StringToHashPolicyType(string algoname, HashPolicyType& hashPolicy);

protected:

	Config*			mConfig;

	HashPolicyType 	mHashPolicy;

	bool			mReportIteration;		// report codetable each iteration
	ReportType		mReportIterType;

	string			mCTFile;

	bool			mWriteLogFile;
	FILE			*mLogFile;
};


#endif // __ALGO_NG_H
