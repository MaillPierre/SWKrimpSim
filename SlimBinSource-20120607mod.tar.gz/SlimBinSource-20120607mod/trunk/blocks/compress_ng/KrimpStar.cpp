//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#ifdef BLOCK_COMPRESS_NG

#include "../global.h"
#include <time.h>
#include <omp.h>
#include <unordered_set>

#include <db/Database.h>
#include <itemstructs/ItemSet.h>
#include <isc/ItemSetCollection.h>

#include "KrimpStar.h"

KrimpStar::KrimpStar(CodeTable* ct, HashPolicyType hashPolicy, Config* config)
: Algo_ng(ct, hashPolicy, config)
{

}

CodeTable* KrimpStar::DoeJeDing(const uint64 candidateOffset /* = 0 */, const uint32 startSup /* = 0 */)
{
	mCompressionStartTime = omp_get_wtime();
	uint64 numM = mISC->GetNumItemSets();
	mNumCandidates = numM;
	bool candidateAccepted = false;
	ItemSet *m;
	mProgress = -1;

	if(mWriteReportFile == true)
		OpenReportFile(true);
	if(mWriteCTLogFile == true) {
		OpenCTLogFile();
		mCT->SetCTLogFile(mCTLogFile);
	}

	mStartTime = time(NULL);
	mScreenReportTime = time(NULL);
	mScreenReportCandidateIdx = 0;
	mScreenReportCandPerSecond = 0;
	mScreenReportCandidateDelta = 5000;

	CoverStats stats = mCT->GetCurStats();
	stats.numCandidates = mNumCandidates;
	printf(" * Start:\t\t(%da,%du,%"I64d",%.0lf,%.0lf,%.0lf)\n",stats.alphItemsUsed, stats.numSetsUsed, stats.usgCountSum,stats.encDbSize,stats.encCTSize,stats.encSize);

	CoverStats &curStats = mCT->GetCurStats();

	double prevIterSize;
	uint64 numIterations = 0;
	uint64 numCandidatesAccepted = 0;
	// TODO: check whether we really need hash set!
	std::unordered_set<uint64> hashedCandidates;
	do {
		prevIterSize = mCT->GetCurSize();

		if(mWriteProgressToDisk) {
			if (numIterations == 0) {
				ProgressToDisk(mCT, 0 /* TODO: should read maximum support */, 0 /* TODO: curLength */, numIterations, true, true);
			}
			else if (mReportIteration && !mReportOnAccept) {
				ProgressToDisk(mCT, 0, 0 /* TODO: curLength */, numIterations, mReportIterType == ReportCodeTable || mReportIterType == ReportAll, mReportIterType == ReportStats || mReportIterType == ReportAll);
			}
		}

		for(uint64 curM=candidateOffset; curM<numM; curM++) {
//			ProgressToScreen(curM, numM); // TODO: Fix!

			m = mISC->GetNextItemSet();
			if(mNeedsOccs)
				mDB->DetermineOccurrences(m);
			m->SetID(curM);

			if(m->GetLength() <= 1)	{	// Skip singleton Itemsets: already in alphabet
				delete m;
				continue;
			}
			if(mHashPolicy != hashNoCandidates && hashedCandidates.find(m->GetID()) != hashedCandidates.end()) {
				delete m;
				continue;
			}

			mCT->Add(m, curM);
			m->SetUsageCount(0);
			mCT->CoverDB(curStats);
			if(curStats.encDbSize < 0) {
				THROW("dbSize < 0. Dat is niet goed.");
			}

			if(mPruneStrategy == PostAcceptPruneStrategy) {						// Post-decide On-the-fly pruning
				if(mCT->GetCurSize() < mCT->GetPrevSize()) {
					mCT->CommitAdd(mWriteCTLogFile);
					PrunePostAccept(mCT);
					candidateAccepted = true;
					if (mHashPolicy != hashNoCandidates)
						hashedCandidates.insert(m->GetID());
				} else {
					mCT->RollbackAdd();
				}
			} else {												// No On-the-fly pruning
				if(mCT->GetCurSize() < mCT->GetPrevSize()) {
					mCT->CommitAdd(mWriteCTLogFile);
					candidateAccepted = true;
					if (mHashPolicy != hashNoCandidates)
						hashedCandidates.insert(m->GetID());
				} else {
					mCT->RollbackAdd();
				}
			}
			if (candidateAccepted) {
				++numCandidatesAccepted;
				if (mReportOnAccept)
					ProgressToDisk(mCT, m->GetSupport(), m->GetLength(), numCandidatesAccepted, mReportAccType == ReportCodeTable || mReportAccType == ReportAll, mReportAccType == ReportStats || mReportAccType == ReportAll);
			}
			candidateAccepted = false;

		}
		if(mPruneStrategy == SanitizeOfflinePruneStrategy) {				// Sanitize post-pruning
			PruneSanitize(mCT);
		}

		mISC->Rewind();
		++numIterations;
	} while (mCT->GetCurSize() < prevIterSize);

	double timeCompression = omp_get_wtime() - mCompressionStartTime;
	printf(" * Time:    \t\tCompressing the database took %f seconds.\t\t\n", timeCompression);

	stats = mCT->GetCurStats();
	printf(" * Result:\t\t(%da,%du,%"I64d",%.0lf,%.0lf,%.0lf)\n",stats.alphItemsUsed, stats.numSetsUsed, stats.usgCountSum,stats.encDbSize,stats.encCTSize,stats.encSize);
	if(mWriteProgressToDisk == true) {
		ProgressToDisk(mCT, mISC->GetMinSupport(), 0 /* TODO: curLength */, numM, true, true);
	}
	CloseCTLogFile();
	CloseReportFile();

	mCT->EndOfKrimp();

	return mCT;
}

#endif // BLOCK_COMPRESS_NG
