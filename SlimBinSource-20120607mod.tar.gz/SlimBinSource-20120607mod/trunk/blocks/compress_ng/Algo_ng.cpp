//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#ifdef BLOCK_COMPRESS_NG

#include "Algo_ng.h"
#include "KrimpSquared.h"
#include "KrimpStar.h"
#include "KrimpPrime.h"
#include "Slim.h"
#include "SlimStar.h"
#include "SlimPlus.h"
#include "SlimCS.h"

Algo_ng::Algo_ng(CodeTable* ct, HashPolicyType hashPolicy, Config* config)
: mHashPolicy(hashPolicy), mConfig(config)
{
	mCT = ct;

	mReportIteration = false;
	mReportIterType = ReportAll;
}

string Algo_ng::GetShortName() {
	return HashPolicyTypeToString(mHashPolicy) + "-" + Algo::GetShortName();
}

Algo* Algo_ng::CreateAlgo(const string &algoname, ItemSetType type, Config* config) {
	if(algoname.compare(0, 6, "krimp-") == 0) {
		return Algo::CreateAlgo(algoname.substr(6), type);
	}
	if(algoname.compare(0, 8, "krimp^2-") == 0) {
		string strippedAlgoname = algoname.substr(8);
		HashPolicyType hashPolicy;
		strippedAlgoname = StringToHashPolicyType(strippedAlgoname, hashPolicy);
		return new KrimpSquared(CodeTable::Create(strippedAlgoname, type), hashPolicy, config);
	}
	if(algoname.compare(0, 7, "krimp*-") == 0) {
		string strippedAlgoname = algoname.substr(7);
		HashPolicyType hashPolicy;
		strippedAlgoname = StringToHashPolicyType(strippedAlgoname, hashPolicy);
		return new KrimpStar(CodeTable::Create(strippedAlgoname, type), hashPolicy, config);
	}
	if(algoname.compare(0, 7, "krimp'-") == 0) {
		string strippedAlgoname = algoname.substr(7);
		HashPolicyType hashPolicy;
		strippedAlgoname = StringToHashPolicyType(strippedAlgoname, hashPolicy);
		return new KrimpPrime(CodeTable::Create(strippedAlgoname, type), hashPolicy, config);
	}
	if(algoname.compare(0, 5, "slim-") == 0) {
		string strippedAlgoname = algoname.substr(5);
		HashPolicyType hashPolicy;
		strippedAlgoname = StringToHashPolicyType(strippedAlgoname, hashPolicy);
		return new Slim(CodeTable::Create(strippedAlgoname, type), hashPolicy, config);
	}
	if(algoname.compare(0, 6, "slim*-") == 0) {
		string strippedAlgoname = algoname.substr(6);
		HashPolicyType hashPolicy;
		strippedAlgoname = StringToHashPolicyType(strippedAlgoname, hashPolicy);
		return new SlimStar(CodeTable::Create(strippedAlgoname, type), hashPolicy, strippedAlgoname, config);
	}
	if(algoname.compare(0, 6, "slim+-") == 0) {
		string strippedAlgoname = algoname.substr(6);
		HashPolicyType hashPolicy;
		strippedAlgoname = StringToHashPolicyType(strippedAlgoname, hashPolicy);
		return new SlimPlus(CodeTable::Create(strippedAlgoname, type), hashPolicy, config);
	}
	if(algoname.compare(0, 7, "slimCS-") == 0) {
		string strippedAlgoname = algoname.substr(7);
		HashPolicyType hashPolicy = hashNoCandidates;
		strippedAlgoname = StringToHashPolicyType(strippedAlgoname, hashPolicy);
		CodeTable *ct = CodeTable::Create(strippedAlgoname, type);
		//Algo_ng *tmp = new SlimCS(ct, hashPolicy, config);
		return new SlimCS(ct, hashPolicy, config);
	}
	return Algo::CreateAlgo(algoname, type);
}

string Algo_ng::HashPolicyTypeToString(HashPolicyType type) {
	switch (type) {
	case hashNoCandidates:
		return "n";
	case hashAllCandidates:
		return "a";
	case hashCtCandidates:
		return "c";
	}
	THROW("Say whut?");
}

string Algo_ng::StringToHashPolicyType(string algoname, HashPolicyType& hashPolicy) {
	hashPolicy = hashNoCandidates;
	if (algoname.compare(0, 2, "n-") == 0) {
		hashPolicy = hashNoCandidates;
		algoname = algoname.substr(2);
	} else if (algoname.compare(0, 2, "a-") == 0) {
		hashPolicy = hashAllCandidates;
		algoname = algoname.substr(2);
	} else if (algoname.compare(0, 2, "c-") == 0) {
		hashPolicy = hashCtCandidates;
		algoname = algoname.substr(2);
	}
	return algoname;
}

void Algo_ng::LoadCodeTable(const string& ctFile) {
	mCT->ReadFromDisk(ctFile, false);
	mCT->CoverDB(mCT->GetCurStats());
	mCT->CommitAdd(); // mAdded = NULL; prevStats = curStats;
}

void Algo_ng::OpenLogFile() {
	string logFilename = mOutDir;
	logFilename.append(mTag);
	logFilename.append(".log");
//	printf("open LogFile: %s\n", logFilename.c_str());
	mLogFile = fopen(logFilename.c_str(), "w");
}

void Algo_ng::CloseLogFile() {
	if(mLogFile) {
//		printf("close LogFile\n");
		fclose(mLogFile);
		mLogFile = NULL;
	}
}

#endif // BLOCK_COMPRESS_NG
