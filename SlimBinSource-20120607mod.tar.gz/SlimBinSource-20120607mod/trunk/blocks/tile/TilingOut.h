//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#ifndef _TILINGOUT_H
#define _TILINGOUT_H

#include <stdio.h>
#if defined (_WINDOWS)
#include <Windows.h>
#endif

#include <Primitives.h>

#include <Croupier.h>
#include "TilingMiner.h"

class Database;
class ItemSet;
enum ItemSetType;

namespace tlngmnr {
	class Output
	{
	public:
		Output(TilingMiner *cr) { mCroupier = cr; mHasBinSizes = false; mFinished = false; }
		virtual ~Output() {
			mCroupier = NULL;
		}

		void SetParameters(bool hbs) { mHasBinSizes = hbs; }

		bool HasBinSizes() { return mHasBinSizes; }

		virtual void SetFinished() { mFinished = true; }
		virtual bool IsFinished() { return mFinished; }

		virtual void OutputParameters() {}
		virtual void OutputSet(uint32 length, uint32 *iset, uint32 support, uint32 area, uint32 ntrans) =0;

	protected:
		bool mHasBinSizes;
		bool mFinished;
		TilingMiner *mCroupier;
	};

	class MemoryOut : public Output
	{
	public:
		MemoryOut(Database *db, TilingMiner *cr);
		virtual ~MemoryOut();

		void	InitBuffer(const uint32 size);
		void	ResizeBuffer(const uint32 size);

		virtual void OutputSet(uint32 length, uint32 *iset, uint32 support, uint32 area, uint32 ntrans);

		virtual void SetFinished();

		ItemSet **GetBuffer()		{ return mBuffer; }
		uint32	GetBufferSize()		{ return mBufferSize; }
		uint32	GetNumInBuffer()	{ return mNumInBuffer; }
		void	EmptyBuffer()		{ mNumInBuffer = 0; }


	protected:
		ItemSet**	mBuffer;
		double*		mStdLengths;
		uint32		mBufferSize;
		uint32		mNumInBuffer;
		ItemSetType	mDataType;
		uint32		mAlphLen;
		uint32*		mSetBuffer;
		uint32		mTotalNum;
		uint32		mScreenUpdateCounter;

		friend class Croupier;
	};

	class FSout : public Output
	{
	public:

		FSout(string filename, TilingMiner *cr);
		virtual ~FSout();

		virtual void OutputParameters();
		virtual void OutputSet(uint32 length, uint32 *iset, uint32 support, uint32 area, uint32 ntrans);

	protected:
		FILE *mFile;
		long long mNumSetPos;
		long long mMinAreaPos;
		long long mMaxSetLenPos;
	};

	/*
	class TileHistogramOut : public TileOutput
	{
	public:
		TileHistogramOut(Database *db, TileMiner *cr);
		virtual ~TileHistogramOut();

		void printSet(int length, int *iset, int support, int ntrans);
		virtual uint64* GetHistogram();
		virtual void finished();

	protected:
		uint64	*mHistogram;
		uint32	mHistoLen;
		TileMiner *mCroupier;
	};

	extern TileOutput *gpout;

	void inline OutputOnePattern(int nitem, int nsupport, int ntrans)
	{
		gntotal_patterns++;
		gppat_counters[gndepth+1]++;

		if(goparameters.bresult_name_given)
		{
			if(gnmax_pattern_len<gndepth+1)
				gnmax_pattern_len = gndepth+1;

			gpheader_itemset[gndepth] = nitem;
			gpout->printSet(gndepth+1, gpheader_itemset, nsupport, ntrans);
		}
	}
*/
}
#endif
