//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#ifdef ENABLE_COMPRESS_NG

#if defined (_WINDOWS)
	#include <direct.h>
	#include <windows.h>
#elif (defined (__unix__) || (defined (__APPLE__) && defined (__MACH__)))
	#include <sys/stat.h>
#endif

// -- qtils
#include <RandomUtils.h>
#include <Config.h>
#include <FileUtils.h>
#include <StringUtils.h>
#include <SystemUtils.h>
#include <TimeUtils.h>
#include <logger/Log.h>

// -- bass
#include <Bass.h>
#include <db/ClassedDatabase.h>
#include <db/DbFile.h>
#include <isc/IscFile.h>
#include <isc/ItemSetCollection.h>
#include <itemstructs/CoverSet.h>

#include "../blocks/compress_ng/Algo_ng.h"
#include "../algo/CodeTable.h"

#include "../FicMain.h"

#include "CompressTH_ng.h"

CompressTH_ng::CompressTH_ng(Config *conf) : TaskHandler(conf){

}

CompressTH_ng::~CompressTH_ng() {
	// not my Config*
}

void CompressTH_ng::HandleTask() {
	string command = mConfig->Read<string>("command");

	if(command.compare("compress") == 0)	Compress(mConfig);
	else	throw string("CompressTH_ng :: Unable to handle task `" + command + "`");
}

string CompressTH_ng::BuildWorkingDir() {
	return mConfig->Read<string>("taskclass") + "/";
}

// Originally, FicMain::Compress
void CompressTH_ng::Compress(Config *config, const string tagIn) {
	// selName	`mushroom-cls-20d-nop`		SelectionName
	// iscName	`mushroom-cls-20d`			ItemSetCollectionName
	// dbName	`mushroom`					DatabaseName

	// Determine ISC properties
	string iscName = config->Read<string>("iscname");

	// Determine DB properties
	string dbName = config->Read<string>("dbname", iscName.substr(0,iscName.find_first_of('-')));
	ItemSetType dataType = ItemSet::StringToType(config->Read<string>("datatype",""));
	DbFileType dbType = DbFile::StringToType(config->Read<string>("dbinencoding",""));

	// Determine Pruning Strategy
	string pruneStrategyStr = config->Read<string>("prunestrategy","nop");

	string tag, timetag;
	if(tagIn.length() == 0) {
		timetag = TimeUtils::GetTimeStampString();
		tag = iscName;
	} else {
		tag = tagIn;
		timetag = tag.substr(tag.find_last_of('-')+1,tag.length()-1-tag.find_last_of('-'));
	}

	// Read DB
	Database *db = Database::RetrieveDatabase(dbName, dataType, dbType);

	// Get ISC
	string iscFullPath = Bass::GetWorkingDir() + iscName + ".isc";

	ItemSetCollection *isc = NULL;
	string iscIfMinedStr = config->Read<string>("iscifmined", "");
	bool loadAll = config->Read<int>("loadall", 0) == 1;		// ??? sander-add
	bool iscBeenMined = false;
	if (config->Read<string>("algo").compare(0, 4, "slim") == 0) { // We don't really need a itemset collection...
		stringstream ss;
		ss << dbName << "-all-" << db->GetNumTransactions()+1 << "d";
		iscName = ss.str();
		iscIfMinedStr = "zap"; // Otherwise, we can crash... don't feel the urgent need to fix this properly ;-(
	}
	try {
		IscFileType storeIscFileType = config->KeyExists("iscStoreType") ? IscFile::ExtToType(config->Read<string>("iscStoreType")) : BinaryFicIscFileType;
		IscFileType chunkIscFileType = config->KeyExists("iscChunkType") ? IscFile::ExtToType(config->Read<string>("iscChunkType")) : BinaryFicIscFileType;
		isc = FicMain::ProvideItemSetCollection(iscName, db, iscBeenMined, iscIfMinedStr.compare("store") == 0, loadAll, storeIscFileType, chunkIscFileType);
	} catch(string msg) {
		delete db;
		throw msg;
	}

	DoCompress(config, db, isc, tag, timetag, 0, 0);
	delete db;
	delete isc;

	if(iscBeenMined == true && iscIfMinedStr.compare("zap") == 0) {	// if stored, it's already gone from workingdir
		FileUtils::RemoveFile(iscFullPath);
	}
}

// Originally, FicMain::DoCompress
void CompressTH_ng::DoCompress(Config *config, Database *db, ItemSetCollection *isc, const string &tag, const string &timetag, const uint32 resumeSup, const uint64 resumeCand) {
	// ISC normalized?
	/*if(!isc->IsNormalized()) {
		delete isc;
		delete db;
		throw string("ItemSetCollection must be normalized before use!");
	}*/

	// Build Algo
	string algoName = config->Read<string>("algo");
	Algo *algo = Algo_ng::CreateAlgo(algoName, db->GetDataType(), config);
	if(algo == NULL)
		throw string("FicMain::DoCompress - Unknown algorithm.");
	ECHO(1, printf("** Compression :: \n"));
	ECHO(3, printf(" * Initiating...\n"));

	// Determine tag, output dir & backup full config
	{
		string outDir = Bass::GetWorkingDir() + tag + "-" + algoName.substr(0, algoName.find_first_of('-')) + "-" + algo->GetShortName() + "-" + config->Read<string>("prunestrategy","nop") + "-" + timetag + "/";
		FileUtils::CreateDir(outDir); /* check succes ? */

		//string confFile = outDir + "/" + config->Read<string>("command") + "-" + TimeUtils::GetTimeStampString() + ".conf";
		string confFile = outDir + "/" + config->Read<string>("command") + "-" + timetag + ".conf";
		config->WriteFile(confFile);
		algo->SetOutputDir(outDir);
		algo->SetTag(tag);

		ECHO(1, printf(" * Experiment tag\t%s\n", tag.c_str()));
	}

	// Further configure Algo
	ECHO(1, printf(" * Algorithm:\t\t%s", algoName.c_str()));
	{
		string		pruneStrategyStr = config->Read<string>("prunestrategy");
		PruneStrategy	pruneStrategy = Algo::StringToPruneStrategy(pruneStrategyStr);
		string pruneStrategyLongName = Algo::PruneStrategyToName(pruneStrategy);
		ECHO(1, printf(" %s\n", pruneStrategyLongName.c_str()))

		uint32		reportSup = config->Read<uint32>("reportsup", 0);
		uint32		reportCnd = config->Read<uint32>("reportcnd", 0);
		bool		reportAcc = config->Read<bool>("reportAcc", false);

		ReportType		reportSupWhat = Algo::StringToReportType(config->Read<string>("reportsupwhat", "all"));
		ReportType		reportCndWhat = Algo::StringToReportType(config->Read<string>("reportcndwhat", "all"));
		ReportType		reportAccWhat = Algo::StringToReportType(config->Read<string>("reportaccwhat", "all"));

		CTInitType	initCT = config->Read<bool>("initct", true) ? InitCTAlpha : InitCTEmpty;

		algo->UseThisStuff(db, isc, db->GetDataType(), initCT, true);
		algo->SetPruneStrategy(pruneStrategy);
		algo->SetReporting(reportSup, reportCnd, reportAcc);
		algo->SetReportStyle(reportSupWhat,reportCndWhat,reportAccWhat);

		Algo_ng* algo_ng = static_cast<Algo_ng*>(algo);
		if (algo_ng) {
			bool reportIter = config->Read<bool>("reportIter", false);
			ReportType reportIterWhat = Algo::StringToReportType(config->Read<string>("reportiterwhat", "all"));
			algo_ng->SetReportIter(reportIter);
			algo_ng->SetReportIterStyle(reportIterWhat);

			string ctFile = config->Read<string>("ctFile", "");
			if (!ctFile.empty())
				algo_ng->SetResumeCodeTable(ctFile);
		}

	}
	ECHO(1, printf(" * Candidates:\t\t%"I64d"p\n", isc->GetNumItemSets()));

	// Resume from specified support or candidate
	uint64 candOffset = 0;
	uint32 startSup = 0;
	if(resumeSup != 0) {
		startSup = resumeSup;
		ECHO(1, printf("** Resuming Compression ::\n * Experiment:\t%s\n", tag.c_str()));
		if(resumeCand == 0) {
			candOffset = isc->ScanPastSupport(resumeSup);
		} else {
			ECHO(1, printf(" * Candidate:\t%"I64d"\n", resumeCand+1));
			isc->ScanPastCandidate(resumeCand);
			candOffset = resumeCand+1;		// +1 want ctCnd geeft laatste candidate die aan codetable heeft bijgedragen weer, dus die skippen we (deze +1 is voor stats)
		}

		// Load appropiate codetable
		algo->LoadCodeTable(resumeSup, resumeCand);
	} else {

		// Write Run-Time Info file
		char rti[100];
		sprintf_s(rti, 100, "__%s %s %s %s", FicMain::ficVersion.c_str(), algo->GetShortName().c_str(), ItemSet::TypeToString(db->GetDataType()).c_str(), algo->GetShortPruneStrategyName().c_str());
		string rtiFile = algo->GetOutDir() + "/" + rti;
		FILE *rtifp = fopen(rtiFile.c_str(), "w");
		fclose(rtifp); /* check success ? */
	}

	// Put algo to work
	CodeTable *ct = algo->DoeJeDing(candOffset, startSup);

	ECHO(3, printf("** Finished compression.\n"));

	// Write transaction covers to disk
	if (config->Read<bool>("writeCover", false)) {
		string filename = algo->GetOutDir() + "/" + tag + ".cover";
		FILE *fp = fopen(filename.c_str(), "w");
		CoverSet* cs = CoverSet::Create(db->GetDataType(), db->GetAlphabetSize());
		for(uint32 r = 0; r < db->GetNumRows(); ++r) {
			ItemSet* t = db->GetRow(r);
			uint32* values = new uint32[t->GetLength()];
			double codeLen = 0.0;

			cs->InitSet(t);

			// item sets (length > 1)
			islist* isl = ct->GetItemSetList();
			for (islist::iterator cit = isl->begin(); cit != isl->end(); ++cit) {
				if(cs->Cover(*cit)) {
					double cl = CalcCodeLength((*cit)->GetUsageCount(), ct->GetCurStats().usgCountSum);
					if (fp) fprintf(fp, "(%s : %.2f) ", (*cit)->ToString(false, false).c_str(), cl);
					codeLen += cl;
				}
			}
			isl->clear();
			delete isl;

			// alphabet items
			islist* sl = ct->GetSingletonList();
			uint32 i = 0;
			for (islist::iterator cit = sl->begin(); cit != sl->end(); ++cit, ++i)
				if(cs->IsItemUncovered(i)) {
					double cl = CalcCodeLength((*cit)->GetUsageCount(), ct->GetCurStats().usgCountSum);
					if (fp) fprintf(fp, "(%s : %.2f) ", (*cit)->ToString(false, false).c_str(), cl);
					codeLen += cl;
				}
			sl->clear();
			delete sl;

			if (fp) fprintf(fp, ": %.2f\n", codeLen);

			delete values;
		}
		delete cs;
		fclose(fp);
	}

	delete algo;
	delete ct;
}

#endif // ENABLE_COMPRESS_NG
